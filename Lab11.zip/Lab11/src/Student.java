public abstract class Student {
    private double gpa;
    private String id;

    protected Student(double gpa, String id){
        this.gpa = gpa;
        this.id = id;
    }

    public abstract String getStatus();


    public final String toString(){
        return this.gpa + "\t" + this.id + "\t" + getStatus();
    }
}
