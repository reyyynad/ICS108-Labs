public class Lab11 {
    public static void main(String args[]){
        Student[] studentsList = new Student[4];
        studentsList[0] = new Undergraduate(3.7, "200000");
        studentsList[1] = new Graduate(3.8, "200001");
        studentsList[2] = new Undergraduate(3.4, "200002");
        studentsList[3] = new Graduate(3.9, "200003");
        for(int i = 0; i< studentsList.length; i++){
            System.out.println(studentsList[i].toString());

        }

    }


}

