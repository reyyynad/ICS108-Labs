public class Undergraduate extends Student{
    private double gpa;
    private String id;
    public Undergraduate(double gpa, String id){
        super(gpa, id);
    }

    @Override
    public String getStatus(){
        if(this.gpa >= 3)
        {
            return "Honor";
        }
        else{
            return "Probation";
        }


    }
}
