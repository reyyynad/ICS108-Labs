public class Graduate extends Student{
    private double gpa;
    private String id;
    public Graduate(double gpa, String id){
        super(gpa, id);
    }

    @Override
    public String getStatus(){
        if(this.gpa >= 3)
        {
            return "Good";
        }
        else{
            return "Probation";
        }


    }
}
