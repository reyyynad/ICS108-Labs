public class MCQuestion extends Question {
    private String choices;
    private String answer;
    public MCQuestion(String text, String choices, String answer) {
        super(text);
        this.choices = choices;
        this.answer = answer;

    }
    public String toString(){
        return super.toString() + "\n" + this.choices + "\n" + this.answer;
    }
}
