public class Question {
    private String text;
    public Question(String text){
        this.text = text;
    }
    public Question(){

    }
    public String toString(){
        return this.text;
    }

    public static void main(String[] args){
        System.out.println("Questions: ");

        MCQuestion  mcq1 = new MCQuestion("Variables that are shared by every instance of a class are:", "a. public varibles\nb. private variables\nc. instance variable\nd. class variables", "answer: d");
        System.out.println(mcq1.toString());


    }

}
