public class Student {
    //A student has ID, name, phone number, and GPA
    private String ID, name, phoneNumber;
    private double GPA;

    public Student(String ID, String name, String phoneNumber, double GPA) {
        this.ID = ID;
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.GPA = GPA;

    }

    public Student() {

    }
    public double getGPA(){
        return this.GPA;
    }

    public String toString() {
        return name + "\t" + phoneNumber + "\t" + "\t" + GPA;

    }



}

