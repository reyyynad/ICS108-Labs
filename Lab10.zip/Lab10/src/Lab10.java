import java.util.ArrayList;

public class Lab10 {
    public static void main(String[] args) {
        Student[] studentsList = createPersonList();
        System.out.println("List of Students");

//1. This method prints the students only
        System.out.println("Name \tPhone \t    ID      Salary");
        printUnderGrad(studentsList);
        double avgGpaUnderGrad = avgGpaUnderGrad(studentsList);
        System.out.println("avg GPA of students = " + avgGpaUnderGrad);


//3. This method prints the students only
        System.out.println("Name \tPhone \t    ID      GPA");
        printGrad(studentsList);

//4. This method finds the average GPA of students
        double avgGpaGrad = avgGpaGrad(studentsList);
        System.out.println("avg GPA of students = " + avgGpaGrad);
    }


    private static Student[] createPersonList() {
        Student[] studentsList = new Student[4];
        studentsList[0] = new Undergraduate("200000", "Renad", "0505320968", 3.7, " FR");
        studentsList[1] = new Graduate("200001", "Yara", "0565320922", 3.9, " KFUPM");
        studentsList[2] = new Undergraduate("200002", "Shatha", "0535324654", 3.8, " JR");
        studentsList[3] = new Graduate("200003", "Ghaida", "0515320465", 3.9, " PNU");
        return studentsList;
    }

    private static void printUnderGrad(Student[] studentsList) {
        for (int i = 0; i < studentsList.length; i++) {
            if (studentsList[i] instanceof Undergraduate) {
                System.out.println(studentsList[i]);

            }

        }
    }

    public static void printGrad(Student[] studentsList) {
        for (int i = 0; i < studentsList.length; i++) {
            if (studentsList[i] instanceof Graduate) {
                System.out.println(studentsList[i]);

            }

        }
    }
    public static double avgGpaUnderGrad (Student[] studentLists) {
        double totalGPA = 0.0;
        int count = 0;
        double averageGPA;
        for (int i = 0; i < studentLists.length; i++) {
            if (studentLists[i] instanceof Undergraduate) {
                totalGPA += studentLists[i].getGPA();
                count ++;

            }
        }
        averageGPA = totalGPA / count;
        return averageGPA;

    }

    public static double avgGpaGrad(Student[] studentLists) {
        double totalGPA = 0.0;
        int counter = 0;
        double averageGPA;
        for (int i = 0; i < studentLists.length; i++) {
            if (studentLists[i] instanceof Graduate) {
                totalGPA += studentLists[i].getGPA();
                counter ++;

            }
        }
        averageGPA = totalGPA / counter;
        return averageGPA;

    }




}
