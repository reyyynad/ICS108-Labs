public class Graduate extends Student{
    String researchArea;
     private double GPA;

    public Graduate(String ID, String name, String phoneNumber, double GPA, String researchArea) {
        super(ID, name, phoneNumber, GPA);
        this.researchArea = researchArea;
    }

    public String toString() {
        return super.toString() + researchArea;

    }


}
