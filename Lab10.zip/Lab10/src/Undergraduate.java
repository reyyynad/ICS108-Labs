public class Undergraduate extends Student{
     private String level;
     private double GPA;

     public Undergraduate(String ID, String name, String phoneNumber, double GPA, String level){
          super(ID, name, phoneNumber, GPA);
          this.level = level;
     }

     public String toString() {
          return super.toString() + level;

     }

}
