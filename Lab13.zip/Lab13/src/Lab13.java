import java.util.Scanner;
public class Lab13 {
    public static void main (String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean continueInput = true;
        do {
            try {
                String timeStr = inputTime();
                String convertedTime = convertTime(timeStr);
                System.out.println (convertedTime);
                System.out.println("Again? (y/n)");
                String answer = scanner.next();
                if(answer.equals("y")) {
                    continue;
                }
                else if (answer.equals("n"))
                    System.out.println("End of program");
                    break;
            }
            catch (TimeFormatException e) {
                System.out.println(e.getMessage());
            }

        }
        while(continueInput);
    }

    private static String inputTime() {
        System.out.println("Enter time in 24-hour notation: ");
        Scanner scanner = new Scanner(System.in);
        return scanner.nextLine();
    }



    private static String convertTime(String timeStr) throws TimeFormatException {
        try {
            int hour = Integer.parseInt(timeStr.substring(0,2));
            int minute = Integer.parseInt(timeStr.substring(3,5));
            if (hour < 0 || hour > 23 || minute < 0 || minute > 59){
                throw new TimeFormatException("There is no such time as " + hour + ":" + String.format("%02d", minute) + "\nTry Again: ");
            }
            else if (hour == 00) {
                return "That is the same as\n" +"12:" + String.format("%02d", minute) + " AM";
            }
            else if (hour < 12) {
                return "That is the same as\n" + hour + ":" + String.format("%02d", minute) + " AM";
            }
            else if (hour == 12) {
                return "That is the same as\n" +"12:" + String.format("%02d", minute) + " PM";
            }

            else {
                return "That is the same as\n" + (hour - 12) + ":" + String.format("%02d", minute) + " PM";
            }


        }

        catch (NumberFormatException s){
            throw new TimeFormatException("Invalid time format \ntry again");
        }
    }
}