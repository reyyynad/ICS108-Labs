import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.TreeMap;
import java.util.TreeSet;

public class Lab22 {
    public static void main(String[] args) {
        String fileName = "enrollment.txt";
        TreeMap<String, TreeSet<Integer>> majors = new TreeMap<>();
        TreeSet<Integer> cs = new TreeSet<>();
        TreeSet<Integer> swe = new TreeSet<>();
        TreeSet<Integer> coe = new TreeSet<>();


        try(BufferedReader bufferedReader = new BufferedReader(new FileReader(fileName))){
            String line;
            while ((line = bufferedReader.readLine()) != null){
                String[] parts = line.split("\t");
                switch (parts[1]) {
                    case "CS" -> cs.add(Integer.parseInt(parts[0]));
                    case "SWE" -> swe.add(Integer.parseInt(parts[0]));
                    case "COE" -> coe.add(Integer.parseInt(parts[0]));
                }


            }
            majors.put("CS", cs);
            majors.put("SWE", swe);
            majors.put("COE", coe);

            for (String major : majors.keySet()){
                System.out.println(major + majors.get(major));
            }


        }

        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
