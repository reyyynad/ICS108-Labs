package com.example.lab16;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.Random;

public class HelloApplication extends Application implements EventHandler<ActionEvent>{

    @Override
    public void start(Stage stage) throws IOException {
        Image[] images = new Image[4];
        images[0] = new Image("C:/Users/ReNaD/Pictures/randomPhotos/p1.jpg");
        images[1] = new Image("C:/Users/ReNaD/Pictures/randomPhotos/p2.jpg");
        images[2] = new Image("C:/Users/ReNaD/Pictures/randomPhotos/p3.jpg");
        images[3] = new Image("C:/Users/ReNaD/Pictures/randomPhotos/p4.jpg");

        ImageView imageView = new ImageView();
        imageView.setFitHeight(300);
        imageView.setFitWidth(300);
        imageView.setX(100);
        imageView.setY(50);


        Button changeImageButton = new Button("Change Image");
        changeImageButton.setLayoutX(200);
        changeImageButton.setLayoutY(400);
        changeImageButton.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                changeImage(images, imageView);
            }
        });

        Pane pane = new Pane();
        pane.getChildren().addAll(imageView, changeImageButton);
        changeImageButton.setAlignment(Pos.CENTER);
        Scene scene = new Scene(pane, 500, 500);
        stage.setScene(scene);
        stage.show();

        changeImage(images, imageView);
       
    }
    public void changeImage(Image[] images, ImageView imageView) {
        int randomNumber = (int)(Math.random()*images.length);
        imageView.setImage(images[randomNumber]);
    }

    

    public static void main(String[] args) {
        launch();
    }

    @Override
    public void handle(ActionEvent actionEvent) {

    }
}