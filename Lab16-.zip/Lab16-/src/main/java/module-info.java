module com.example.lab16 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.lab16 to javafx.fxml;
    exports com.example.lab16;
}