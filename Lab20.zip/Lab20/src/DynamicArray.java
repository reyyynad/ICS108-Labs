import java.util.ArrayList;

public class DynamicArray<T> {
    private int size;
    private T[] array;

    public DynamicArray() {
        array = (T[]) new Object[2];
        size = 0;
    }

    public void add(T item) {
        if (array.length == size) {
            T[] newArray = (T[]) new Object[array.length * 2];
            System.arraycopy(array, 0, newArray, 0, array.length);
            array = newArray;
            array[size] = item;
            size++;


        } else {
            array[size] = item;
            size++;

        }


    }

    public T remove() {
        if (size == 0) {
            return null;
        }
        else {
            T lastItem = array[size - 1];
            array[size - 1] = null;
            size--;
            return lastItem;

        }
    }

        public String toString() {
            String list = "";
            for (int i = 0; i < array.length-1; i++) {
                list = list + array[i] + ", ";
            }
            return "[" + list + array[array.length-1] + "]";
        }
    }

