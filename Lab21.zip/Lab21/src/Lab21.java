import java.util.*;


public class Lab21 {
    public static void main(String[] args) {
        LinkedList<Integer> linkedList = new LinkedList<>();
        for (int i=2; i<=100; i++){
            linkedList.add(i);
        }
        for (int number:  new LinkedList<>(linkedList)){

            ListIterator<Integer> listIterator = linkedList.listIterator();

            while (listIterator.hasNext()){

                Integer value = listIterator.next();
                if (value%number==0 && number!=value){
                    listIterator.remove();
                }
            }
        }
        System.out.println(linkedList);
    }
}