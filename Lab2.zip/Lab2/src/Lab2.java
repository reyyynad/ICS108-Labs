import java.util.Random;
import java.util.Scanner;

public class Lab2 {
    public static void printNRandomLetterGrades(int n) {
        String[] grades = {"A+", "A", "B+", "B", "C+", "C", "D+", "D", "F"};
        Random rand = new Random();
        for (int i = 0; i < n; i++) {
            int index = rand.nextInt(grades.length);
            System.out.println(grades[index]);
        }
    }
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        System.out.println("How many letter grades?");
        int n = input.nextInt();
        printNRandomLetterGrades(n);
    }



    }
