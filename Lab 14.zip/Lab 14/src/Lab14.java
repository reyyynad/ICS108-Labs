import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Random;
import java.util.Scanner;

public class Lab14 {

    public static void main(String[] args) {
        Random random = new Random();
        int n = random.nextInt(10) + 1;
        int[] numbers = new int[n];
        for (int i = 0; i < n; i++) {
            numbers[i] = random.nextInt(101);
        }

        String filename = "Numbers.txt";
        try {
            PrintWriter writer = new PrintWriter(filename);
            for (int number : numbers) {
                writer.println(number);
            }
            writer.close();
            System.out.println("File created: " + filename);
        } catch (FileNotFoundException e) {
            System.out.println("Error creating file: " + filename);
        }

        try {
            File file = new File(filename);
            Scanner scanner = new Scanner(file);
            int sum = 0;
            int count = 0;
            while (scanner.hasNextInt()) {
                int number = scanner.nextInt();
                sum += number;
                count++;
            }
            scanner.close();
            double average = (double) sum / count;
            System.out.println("Average: " + average);
        } catch (FileNotFoundException e) {
            System.out.println("Error reading file: " + filename);
        }
    }
}