public class Student extends Person{
    private String id;
    private String GPA;
    public Student(String phoneNumber, String name, String id, String GPA){
        super(phoneNumber, name);
        this.id = id;
        this.GPA = GPA;
    }
    public String getGPA(){
        return this.GPA;
    }
    public void setGPA(){
        this.GPA = GPA;
    }

    public String toString(){
        return super.toString() + ", ID: " + this.id + ", GPA: " + this.GPA;
    }
}
