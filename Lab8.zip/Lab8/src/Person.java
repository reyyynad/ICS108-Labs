public class Person {
    private String phoneNumber;
    private String name;
    public Person(String phoneNumber, String name){
        this.phoneNumber = phoneNumber;
        this.name = name;
    }
    public Person(){
        
    }
    public String getPhoneNumber(){
        return this.phoneNumber;
    }
    public void setPhoneNumber(String phoneNumber){
        this.phoneNumber = phoneNumber;
    }
    
    public String name(){
        return this.name;
    }
    public String toString(){
        return "Name: " + this.name + "," + " Phone number: " + this.phoneNumber;
    }
    public static void main(String[] args){
        Person person = new Person ("0501331845", "Salem");
        Student student = new Student("0564448202", "Reem", "200000", "3.6");
        Employee employee = new Employee("0563428255", "Saad", "200003", "16000");
        System.out.println(person.toString());
        System.out.println(student.toString());
        System.out.println(employee.toString());
    }
}
