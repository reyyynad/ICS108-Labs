public class Employee extends Person{
    private String id;
    private String monthlySalary;
    public Employee(String phoneNumber, String name, String id, String monthlySalary){
        super(phoneNumber, name);
        this.id = id;
        this.monthlySalary = monthlySalary;
    }
    public String getMonthlySalary(){
        return this.monthlySalary;
    }
    public void setMonthlySalary(){
        this.monthlySalary = monthlySalary;
    }
    public String toString(){
        return super.toString() + ", ID: " + this.id + ", Monthly salary: " + this.monthlySalary + " SAR";
    }

}
