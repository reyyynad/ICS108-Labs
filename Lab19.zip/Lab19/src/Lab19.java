import java.io.File;
import java.util.Scanner;

public class Lab19 {

    public static void main(String[] args) {

        System.out.println("Enter a directory path: ");

        Scanner input = new Scanner(System.in);

        String path = input.next();

        File f = new File(path);

        if (f.isDirectory()){

            printFiles(f);

        }


    }

    public static void printFiles(File f) {

        int space =0;

        printFiles(f,space);

    }

    public static void printFiles(File f,int space) {

        File[] files = f.listFiles();

        if (files != null){

            for (File file:files){

                for (int i=0;i<space;i++){

                    System.out.print(" ");

                }

                System.out.println(file.getName());

                if (file.isDirectory()){

                    space++;

                    printFiles(file,space);

                }

            }

        }

    }

}





