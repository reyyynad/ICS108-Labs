import java.util.ArrayList;
public class Lab09 {
    public static void main(String[] args) {
        ArrayList<Person> personList = createPersonList();
        System.out.println("List of Employees");

//1. This method prints the employees only
        System.out.println("Name \tPhone \t    ID      Salary");
        printEmployees(personList);

//2. This method finds the average salary of employees
        double avgSalary = avgSalary(personList);
        System.out.println("avg salary of = " + avgSalary);

//3. This method prints the students only
        System.out.println("Name \tPhone \t    ID      GPA");
        printStudents(personList);

//4. This method finds the average GPA of students
        double avgGpa = avgGpa(personList);
        System.out.println("avg GPA of students = " + avgGpa);
    }





    private static ArrayList<Person> createPersonList() {
        ArrayList<Person> personList = new ArrayList<>();
        personList.add(new Employee("Saad", "0563428255", 200003, 16000));
        personList.add(new Student("Reem", "0564448202", 20000, 3.6));
        personList.add(new Employee("Salem", "0501331845", 200001, 9000));
        personList.add(new Student("Hasan", "0594448202", 20002, 2.8));
        return personList;
    }

    private static void printStudents(ArrayList<Person> personList) {
        for (int i = 0; i < personList.size(); i++) {
            if (personList.get(i) instanceof Student) {
                Student student = (Student) personList.get(i);
                System.out.println(student);

            }

        }
    }
    public static void printEmployees(ArrayList<Person> personList) {
        int size = personList.size();
        for (int i = 0; i < personList.size(); i++) {
            if (personList.get(i) instanceof Employee) {
                Employee employee = (Employee) personList.get(i);
                System.out.println(employee);
            }
        }
    }
        public static double avgSalary (ArrayList < Person > personList) {
            double totalSalary = 0.0;
            int counter = 0;
            double averageSalary;
            for (int i = 0; i < personList.size(); i++) {
                if (personList.get(i) instanceof Employee) {
                    Employee employee = (Employee) personList.get(i);
                    totalSalary += employee.getSalary();
                    counter ++;

                }

            }
            averageSalary = totalSalary / counter;
            return averageSalary;

        }

        public static double avgGpa (ArrayList < Person > personList) {
            double totalGPA = 0.0;
            int count = 0;
            double averageGPA;
            for (int i = 0; i < personList.size(); i++) {
                if (personList.get(i) instanceof Student) {
                    Student student = (Student) personList.get(i);
                    totalGPA += student.getGpa();
                    count ++;

                }
            }
            averageGPA = totalGPA / count;
            return averageGPA;

        }

    }

