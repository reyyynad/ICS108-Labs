import java.util.ArrayList;
import java.util.Arrays;

public class Lab18 {
    public static void main(String[] args){
        Integer[] array = {1, 2, 1, 3, 1};
        ArrayList<Integer> arrayList = new ArrayList<>(Arrays.asList(array));
        Integer target = 1;
        remove(arrayList, target);


    }

    public static void remove(ArrayList<Integer> list, Integer target){
        if(! list.contains(target)){
            System.out.println("list after removing" + target + " "+ list);


        }
        else {
            list.remove(target);
            remove(list, target);
        }

    }
}
