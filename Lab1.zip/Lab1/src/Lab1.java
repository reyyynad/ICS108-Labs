import java.util.Scanner;

public class Lab1 {
    public static void main(String[] args) {
        System.out.println("How many courses? ");
        Scanner scanner = new Scanner(System.in);
        int number = scanner.nextInt();
        System.out.println("Enter letter grade, credit hours for " + number + " courses");
        String letterGrade;
        double creditHours;
        double totalMarks = 0.0;
        double totalCredit = 0.0;
        for (int i = 0; i < number; i++) {
            letterGrade = scanner.next();
            creditHours = scanner.nextInt();
            totalCredit += creditHours;

            if (letterGrade.equals("A+"))
                totalMarks += (4.0 * creditHours);
            else if (letterGrade.equals("A"))
                totalMarks += (3.75 * creditHours);
            else if (letterGrade.equals("B+"))
                totalMarks += (3.5 * creditHours);
            else if (letterGrade.equals("B"))
                totalMarks += (3.0 * creditHours);
            else if (letterGrade.equals("C+"))
                totalMarks += (2.5 * creditHours);
            else if (letterGrade.equals("C"))
                totalMarks += (2.0 * creditHours);
            else if (letterGrade.equals("D+"))
                totalMarks += (1.5 * creditHours);
            else if (letterGrade.equals("D"))
                totalMarks += (1.0 * creditHours);
            else if (letterGrade.equals("F"))
                totalMarks += (0.0 * creditHours);

        }
        double GPA = (totalMarks / totalCredit);
        System.out.printf("GPA = %6.2f", GPA);

    }
}