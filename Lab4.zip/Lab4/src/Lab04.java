import java.util.ArrayList;
import java.util.Scanner;
public class Lab04 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        final int MAX_WEIGHT = 10;

        System.out.print("Enter the number of objects: ");

        int objects = scanner.nextInt();

        ArrayList<Integer> weights = new ArrayList<Integer>();

        System.out.print("Enter the weights of the objects: ");

// Make an array for the weight of each object

        for (int i = 0; i < objects; i++) {

            int userWeight = scanner.nextInt();

            weights.add(userWeight);

        }

        int counter = 1;

        ArrayList<ArrayList<Integer>> containers = new ArrayList<ArrayList<Integer>>();

        while (
                !weights.isEmpty()
        ) {

            ArrayList<Integer> objectsOfContainer = new ArrayList<>();

            int total = 0;

            int number;

            for (int i = 0; i < weights.size(); i++) {

                if (
                        (total + weights.get(i)
                        ) <= MAX_WEIGHT) {

                    number = weights.remove(i);

                    i--;

                    objectsOfContainer.add(number);

                    total += number;

                }

            }

            containers.add(objectsOfContainer);

        }

        for (int i = 0; i < containers.size(); i++) {

            ArrayList<Integer> container = containers.get(i);

            System.out.print("Container " + (i + 1) + " contains objects with weight: ");

            for (int j = 0; j < container.size(); j++) {

                System.out.print(container.get(j) + " ");

            }

            System.out.println();

        }

    }
}

