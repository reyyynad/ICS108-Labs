package com.example.lab17;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.io.IOException;
import java.util.Stack;

public class HelloApplication extends Application {
    private Timeline animation;
    private Image[] images = new Image[3];
    private ImageView imageView = new ImageView();

    @Override
    public void start(Stage stage) throws IOException {

       images[0] = new Image("C:/Users/ReNaD/Pictures/randomPhotos/p1.jpg");
       images[1] = new Image("C:/Users/ReNaD/Pictures/randomPhotos/p2.jpg");
       images[2] = new Image("C:/Users/ReNaD/Pictures/randomPhotos/p3.jpg");


        imageView.setFitHeight(300);
        imageView.setFitWidth(300);
        imageView.setX(100);
        imageView.setY(50);

        Button playButton = new Button("Play");
        Button pauseButton = new Button("Pause");
        Button increaseSpeedButton = new Button();
        Button decreaseSpeedButton = new Button();

        //add image for increase and decrease  button

        ImageView incImage = new ImageView(new Image("C:/Users/ReNaD/Pictures/randomPhotos/download.png"));
        incImage.setFitHeight(50);
        incImage.setFitWidth(50);


        ImageView decImage = new ImageView(new Image("C:/Users/ReNaD/Pictures/randomPhotos/5e8f3769652154c09064e81af4ea0f8a.jpg"));
        decImage.setFitHeight(50);
        decImage.setFitWidth(50);

        playButton.setMaxHeight(70);
        pauseButton.setMaxHeight(70);

        increaseSpeedButton.setGraphic(incImage);
        decreaseSpeedButton.setGraphic(decImage);



        playButton.setOnAction(e-> play());
        pauseButton.setOnAction(e-> pause());
        increaseSpeedButton.setOnAction(e-> increaseSpeed());
        decreaseSpeedButton.setOnAction(e-> decreaseSpeed());

        HBox pane = new HBox();
        VBox box = new VBox();
        box.getChildren().addAll(playButton,pauseButton, increaseSpeedButton,decreaseSpeedButton);
        BorderPane.setAlignment(pane, Pos.CENTER);

        pane.getChildren().addAll(imageView, box);
        Scene scene = new Scene(pane, 500, 500);
        stage.setScene(scene);
        stage.show();


        animation = new Timeline(new KeyFrame(Duration.seconds(2),e-> changeImage(images, imageView))
        );
        animation.setCycleCount(Timeline.INDEFINITE);
        animation.play();

    }

    public void play(){
        animation.play();
    }

    public void pause(){
        animation.pause();
    }

    public void increaseSpeed(){
        animation.setRate(animation.getRate() + 0.1);
    }

    public void decreaseSpeed(){
        if(animation.getRate() > 1){
            animation.setRate(
                    animation.getRate() - 0.1);
        }
    }

    public void changeImage(Image[] images, ImageView imageView) {
        int randomNumber = (int)(Math.random()*images.length);
        imageView.setImage(images[randomNumber]);
    }

}




