module com.example.lab15 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.lab15 to javafx.fxml;
    exports com.example.lab15;
}