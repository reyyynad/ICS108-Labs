public class Lab12 {
    public static void main(String[] args){
        // Create new objects of type City
        City city1 = new City("Khartoum", 35);
        City city2 = new City("Riyadh", 40);
        City city3 = new City("Dhahran", 41);
        City[] cities = {city1, city2,(City) city1.clone(), (City) city3.clone()};

        // printing the city names using a getter
        for (int i = 0; i < cities.length; i++) {
            System.out.println(cities[i].getCityName());
        }



        // Testing compareTo and toString method
        if (city1.compareTo(city2) > 0)
            System.out.println(city1.toString() + " hotter than " + city2.toString());
        else if (city1.compareTo(city2) < 0)
            System.out.println(city1.toString() + " colder than " + city2.toString());
        else
            System.out.println(city1.toString() + " and " + city2.toString() + " have the same in temperature");

        // Testing equals() method and clone()
        City city4;
        city4 = city1;
        System.out.println("----------------------");
        System.out.println("Comparing city names: " + city1.clone().equals(city4));
        System.out.println("Comparing the references: " + (city1 == city1.clone()));

    }
}
