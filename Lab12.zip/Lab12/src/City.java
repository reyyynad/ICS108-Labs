public class City implements Comparable<City>, Cloneable {
    private String cityName;
    private int temperature;

    City(String cityName, int temperature) {
        this.cityName = cityName;
        this.temperature = temperature;
    }

    protected String getCityName() {
        return cityName;
    }

    protected int getTemperature() {
        return temperature;
    }

    @Override
    public int compareTo(City city) {
        if (temperature > ((City) city).getTemperature())
            return 1;
        else if (temperature < ((City) city).getTemperature())
            return -1;
        return 0;
    }

    @Override
    public Object clone() {             // Cloneable interface
        try {
            return super.clone();
        } catch (CloneNotSupportedException v) {
            return "Can't be cloned";
        }
    }

    @Override
    public boolean equals(Object city) {  // Super class Object
        if (temperature == ((City) city).getTemperature())
            return true;

        return false;
    }

    @Override
    public String toString() {
        return "City (" + cityName + ") with a temperature (" + temperature + ")";
    }
}